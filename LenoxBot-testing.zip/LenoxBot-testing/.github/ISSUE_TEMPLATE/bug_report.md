---
name: Bug report
about: Create a report to help us improve
title: ''
labels: 't: bugreport'
assignees: ''

---

**What is the title of your bugreport?**


**Is it a bugreport for the website or for the bot?**

- [ ] Bot
- [ ] Website

**How can you reproduce the bug? (Explain in steps)**
Steps to reproduce the behavior:

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Which result would normally have to be?**


**What happens if you do the action now?**


**Additional context**
