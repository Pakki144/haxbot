---
name: Feature request
about: Request a feature for LenoxBot
title: ''
labels: 't: enhancement'
assignees: ''

---

**What is the title of your proposal?**


**Is it a suggestion for the website or for the bot?**

- [ ] Bot
- [ ] Website

**Explain your proposal more accurately (It's best to give as much information as possible, so that we can implement the proposal better)**


**Why should we add this feature?**
